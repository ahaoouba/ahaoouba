i18n
====

Package i18n is for app Internationalization and Localization.

[Documentation](http://beego.me/docs/module/i18n.md)
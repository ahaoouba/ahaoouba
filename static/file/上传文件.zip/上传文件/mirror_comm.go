package v1

import (
	"common/ajax"
	"common/base"
	"dashboard/config"
	"dashboard/services"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"

	"github.com/astaxie/beego"
)

type PlatformMirrorCommController struct {
	beego.Controller
}

//获取镜像仓库列表
//创建人:贾浩
//创建时间:2017-8-4 15:00:47
func (this *PlatformMirrorCommController) GetReposList() {
	this.Data["tokenflag"] = this.Ctx.Input.Param("tokenflag")
	this.TplName = "mirrorComm/mirrorComm.html"
	bp := base.NewBaseParamParser(config.DefaultConfig.Page.Limit, config.DefaultConfig.Page.MaxLimit)
	opt := new(services.QueryReposOptions)
	opt.BaseOption = bp.BaseParam(this.Ctx.Input)
	rps := make([]*services.Repo, 0)
	//分页
	page, err := this.GetInt("p", 1)
	if err != nil {
		beego.Error(err)
		return
	}

	//运算偏移量
	opt.BaseOption.Offset = (page - 1) * opt.BaseOption.Limit
	res, err := services.GetReposList(opt)
	if err != nil {
		beego.Error(err)
		return
	}
	bys, err := json.Marshal(res.Result["repos"])
	if err != nil {
		beego.Error(err)
		return
	}
	err = json.Unmarshal(bys, &rps)
	if err != nil {
		beego.Error(err)
		return
	}

	this.Data["repos"] = rps

	this.Data["page"] = services.NewPage(len(rps), page, opt.BaseOption.Limit, this.Ctx.Request.URL.String())
}

//删除镜像仓库
//创建人:贾浩
//创建时间:2017-8-4 15:59:56
func (this *PlatformMirrorCommController) DeleteRepo() {
	ar := ajax.NewAjaxResult()
	this.Data["json"] = ar

	name := this.GetString("name", "")
	tag := this.GetString("tag", "")
	if name == "" {
		ar.SetError(fmt.Sprintf("名称不能为空!"))
		beego.Error(ar.Errmsg)
		this.ServeJSON()
		return
	}
	if tag == "" {
		ar.SetError(fmt.Sprintf("标签不能为空!"))
		beego.Error(ar.Errmsg)
		this.ServeJSON()
		return
	}
	res, err := services.DelRepoInfo(name, tag)
	if err != nil {
		ar.SetError(fmt.Sprintf("删除镜像仓库发生异常，错误内容为：[ %s ]", err.Error()))
		beego.Error(ar.Errmsg)
		this.ServeJSON()
		return
	}
	ar.Success = res.Success
	ar.Errmsg = res.Error.Msg

	this.ServeJSON()
	return
}

//镜像仓库详情页
//创建人:贾浩
//创建时间:2017-8-7 10:24:32
func (this *PlatformMirrorCommController) DetailPage() {
	this.Data["tokenflag"] = this.Ctx.Input.Param("tokenflag")
	this.TplName = "mirrorComm/imagesdetail.html"

	name := this.GetString("name", "")

	tags := this.GetStrings("tag", []string{})
	if name == "" {
		beego.Error(errors.New("镜像仓库名称不能为空!"))
		return
	}
	if len(tags) == 0 {
		beego.Error(errors.New("标签不能为空!"))
		return
	}
	dlarr := make([]*services.Detail, 0)
	for i := 0; i < len(tags); i++ {
		res, err := services.GetImageDetail(name, tags[i])
		if err != nil {
			beego.Error(err)
			return
		}
		byt, err := json.Marshal(res.Result["detail"])
		if err != nil {
			beego.Error(err)
			return
		}
		dl := new(services.Detail)
		err = json.Unmarshal(byt, dl)
		if err != nil {
			beego.Error(err)
			return
		}
		dl.Name, _ = url.QueryUnescape(dl.Name)
		dlarr = append(dlarr, dl)
	}
	this.Data["Details"] = dlarr
}

//镜像仓库详情页Ajax
//创建人:贾浩
//创建时间:2017-8-7 15:33:16
func (this *PlatformMirrorCommController) DetailAjax() {
	ar := ajax.NewAjaxResult()
	this.Data["json"] = ar

	name := this.GetString("name", "")
	tag := this.GetString("tag", "")
	if name == "" {
		ar.SetError(fmt.Sprintf("名称不能为空!"))
		beego.Error(ar.Errmsg)
		this.ServeJSON()
		return
	}
	if tag == "" {
		ar.SetError(fmt.Sprintf("标签不能为空!"))
		beego.Error(ar.Errmsg)
		this.ServeJSON()
		return
	}
	res, err := services.GetImageDetail(name, tag)
	if err != nil {
		beego.Error(err)
		return
	}
	byt, err := json.Marshal(res.Result["detail"])
	if err != nil {
		beego.Error(err)
		return
	}
	dl := new(services.Detail)
	err = json.Unmarshal(byt, dl)
	if err != nil {
		beego.Error(err)
		return
	}
	dl.Name, _ = url.QueryUnescape(dl.Name)
	ar.Data = dl
	this.ServeJSON()
}

//推送镜像仓库Ajax
//创建人:贾浩
//创建时间:2017-8-10 10:22:42
func (this *PlatformMirrorCommController) PushImage() {
	ar := ajax.NewAjaxResult()
	this.Data["json"] = ar
	f, fh, err := this.GetFile("file[]")
	if err != nil {
		ar.SetError(fmt.Sprintf("获取镜像文件发生异常，错误原因为:[ %s ]!", err))
		beego.Error(ar.Errmsg)
		this.ServeJSON()
		return
	}
	defer f.Close()
	result, err := services.PushImages(fh.Filename, f)
	if err != nil {
		ar.SetError(err.Error())
		beego.Error(ar.Errmsg)
		this.ServeJSON()
		return
	}
	if !result.Success {
		ar.SetError(result.Error.Msg)
		beego.Error(ar.Errmsg)
		this.ServeJSON()
		return
	}

	this.ServeJSON()

}
func (this *PlatformMirrorCommController) Add() {
	this.Data["tokenflag"] = this.Ctx.Input.Param("tokenflag")
	this.TplName = "mirrorComm/mirrorCommAdd.html"
}

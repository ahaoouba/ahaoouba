package services

import (
	"bytes"
	"common/base"
	//	"dashboard/plugin/registry"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"net/url"
	"strconv"

	"github.com/astaxie/beego/httplib"
)

type Label struct {
}
type Images struct {
	Containers  int
	Created     float64
	Id          string
	Labels      Label
	ParentId    string
	RepoDigests []string
	RepoTags    []string
	SharedSize  int
	Size        float64
	VirtualSize float64
}
type QueryImagesOptions struct {
	BaseOption *base.QueryOptions
}

//func getRepositoryApiAddress() (string, error) {
//	addr, err := registry.GetGconfigCenterService()
//	if err != nil {
//		return "", err
//	}
//	beego.Debug("GconfigAddress:	", addr)
//	return fmt.Sprintf("http://%s", addr), nil
//}

//获取本地镜像列表
//创建人:贾浩
//创建时间:2017-8-4 13:45:32
func GetImagesList(opt *QueryImagesOptions) (*base.ApiResult, error) {
	addr, err := getPlatformServiceApiAddress()
	if err != nil {
		return nil, fmt.Errorf("获取镜像管理服务地址发生错误，错误原因为：[ %s ]", err.Error())
	}
	apiAddr := fmt.Sprintf("%s/platform_repository/v1/images", addr)
	link, err := url.ParseRequestURI(apiAddr)
	if err != nil {
		return nil, err
	}

	values := link.Query()

	values.Add("limit", strconv.Itoa(opt.BaseOption.Limit))
	values.Add("offset", strconv.Itoa(opt.BaseOption.Offset))

	link.RawQuery = values.Encode()
	apiURL := link.String()
	req := httplib.Get(apiURL)
	result := new(base.ApiResult)
	err = req.ToJSON(result)
	if err != nil {
		return nil, err
	}
	if result.Success {
		return result, nil
	} else {
		return nil, errors.New(result.Error.Msg)
	}
}

//推送至镜像仓库
//创建人:贾浩
//创建时间:2017-8-10 10:41:27
func PushImages(filename string, src io.Reader) (*base.ApiResult, error) {

	addr, err := getPlatformServiceApiAddress()
	if err != nil {
		return nil, fmt.Errorf("获取镜像管理服务地址发生错误，错误原因为：[ %s ]", err.Error())
	}
	apiAddr := fmt.Sprintf("%s/platform_repository/v1/images", addr)

	bodyBuf := &bytes.Buffer{}
	bodyWriter := multipart.NewWriter(bodyBuf)

	fileWriter, err := bodyWriter.CreateFormFile("file", filename)
	if err != nil {
		return nil, err
	}
	_, err = io.Copy(fileWriter, src)
	if err != nil {
		return nil, err
	}

	contentType := bodyWriter.FormDataContentType()
	bodyWriter.Close()

	resp, err := http.Post(apiAddr, contentType, bodyBuf)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	resp_body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	result := new(base.ApiResult)

	err = json.Unmarshal(resp_body, result)
	if err != nil {
		return nil, err
	}
	if result.Success {
		return result, nil
	} else {
		return result, errors.New(result.Error.Msg)
	}

}
